# libborderless
Borderless toggle extension for GameMaker Studio.
